import pytest
from app import app

@pytest.fixture
def client():
    with app.test_client() as client:
        yield client

def test_add_vegetable(client):
    vegetable_data = {
        "name": "Test Vegetable",
        "stock": 50,
        "expiry_date": "2024-06-30",
        "supplier": "Test Supplier"
    }
    response = client.post('/vegetables', json=vegetable_data)
    assert response.status_code == 201

def test_get_vegetable(client):
    response = client.get('/vegetables/1')
    assert response.status_code == 200

def test_update_vegetable(client):
    updated_data = {
        "stock": 100
    }
    response = client.put('/vegetables/update/1', json=updated_data)
    assert response.status_code == 200

def test_delete_vegetable(client):
    response = client.delete('/vegetables/delete/1')
    assert response.status_code == 200
