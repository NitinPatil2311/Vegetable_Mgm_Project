from flask import Flask, jsonify, request, render_template

app = Flask(__name__)

vegetables = [{"id":1, "name":"Carrot", "stock":100, "expiry_date": "2024-05-30", "supplier":"Farm A"},
              {"id":2, "name":"Broccoli", "stock":75, "expiry_date": "2024-05-28", "supplier":"Farm B"},
              {"id":3, "name":"Onion", "stock":50, "expiry_date": "2024-06-15", "supplier":"Farm C"},
              {"id":4, "name":"Cabbage", "stock":25, "expiry_date": "2024-06-01", "supplier":"Farm D"},
              {"id":5, "name":"Tomato", "stock":100, "expiry_date": "2024-05-25", "supplier":"Farm E"}]

# Read
@app.route('/vegetables', methods=['GET'])
def get_vegetables():
    return render_template('vegetables.html', vegetables=vegetables)

# Create
@app.route('/vegetables/add', methods=['POST'])
def add_vegetable():
    name = request.form.get('name')
    stock = int(request.form.get('stock'))
    expiry_date = request.form.get('expiry_date')
    supplier = request.form.get('supplier')
    
    if not all([name, stock, expiry_date, supplier]):
        return jsonify({"message": "Invalid request. Please provide name, stock, expiry_date, and supplier"}), 400
    
    new_vegetable = {
        "id": len(vegetables) + 1,
        "name": name,
        "stock": stock,
        "expiry_date": expiry_date,
        "supplier": supplier
    }
    vegetables.append(new_vegetable)
    return jsonify(new_vegetable), 201

# Update
@app.route('/vegetables/update/<int:id>', methods=['PUT'])
def update_vegetable(id):
    vegetable = next((veg for veg in vegetables if veg['id'] == id), None)
    if vegetable:
        data = request.json
        vegetable.update(data)
        return jsonify(vegetable), 200
    else:
        return jsonify({"message": "Vegetable not found"}), 404
    
# Delete
@app.route('/vegetables/delete/<int:id>', methods=['DELETE'])
def delete_vegetable(id):
    global vegetables
    vegetables = [veg for veg in vegetables if veg['id'] != id]
    return jsonify({"message": "Vegetable deleted"}), 200

if __name__ == '__main__':
    app.run(debug=True)
