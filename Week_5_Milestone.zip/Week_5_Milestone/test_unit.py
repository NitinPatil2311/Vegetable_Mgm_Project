import unittest
# from unittest import TestCase
from app import app

class TestVegetableManagement(unittest.TestCase):
    
    def setUp(self):
        self.app = app.test_client()
        self.vegetable_data = {
            "name": "Test Vegetable",
            "stock": 50,
            "expiry_date": "2024-06-30",
            "supplier": "Test Supplier"
        }
    
    def test_add_vegetable(self):
        response = self.app.post('/vegetables', json=self.vegetable_data)
        self.assertEqual(response.status_code, 201
                         )
    
    def test_get_vegetable(self):
        response = self.app.get('/vegetables/1')
        self.assertEqual(response.status_code, 200)
    
    def test_update_vegetable(self):
        updated_data = {
            "stock": 100
        }
        response = self.app.put('/vegetables/update/1', json=updated_data)
        self.assertEqual(response.status_code, 200)
    
    def test_delete_vegetable(self):
        response = self.app.delete('/vegetables/delete/1')
        self.assertEqual(response.status_code, 200)

if __name__ == '__main__':
    unittest.main()
